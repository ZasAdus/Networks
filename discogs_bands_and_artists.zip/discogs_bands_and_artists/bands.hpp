#ifndef bands_hpp
#define bands_hpp

#include <vector>
#include <iostream>

void print_common_groups();

#endif