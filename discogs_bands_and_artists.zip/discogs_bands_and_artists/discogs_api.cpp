#include "discogs_api.hpp"
#include <curl/curl.h>
#include <iostream>

std::vector<std::unique_ptr<Artist>> artist_ptrs;

int fetch_artist(int artist_id){
    
    CURL* curl = curl_easy_init();
    if(!curl){
        std::cerr << "Error, couldn't init curl" << std::endl;
        return 1;
    }
    
    std::string url = "https://api.discogs.com/artists/" + std::to_string(artist_id);
    auto artist = std::make_unique<Artist>(artist_id);
    Artist* ptr = artist.get();

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, Artist::callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, ptr);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "ZasAdus");

    CURLcode res = curl_easy_perform(curl);
    
    if(res != CURLE_OK){
        std::cerr << "Error, cURL" << std::endl;
        curl_easy_cleanup(curl);
        return 1;
    }
    
    int http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    
    curl_easy_cleanup(curl);
    
    if(http_code != 200) {
        std::cerr << "Error, http: " << http_code << std::endl;
        return 1;
    }
    
    ptr->get_bands();
    artist_ptrs.push_back(std::move(artist));
    return 0;
}
